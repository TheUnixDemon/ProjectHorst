- li
- li

mixed unordered markers:

* li
+ li
- li

mixed ordered markers:

1. starting at 1, list one
2. number 2, list one
3) starting at 3, list two