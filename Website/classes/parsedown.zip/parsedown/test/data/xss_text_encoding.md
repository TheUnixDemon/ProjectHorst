<script>alert(1)</script>

<script>

alert(1)

</script>


<script>
alert(1)
</script>