my email is <me@example.com>

html tags shouldn't start an email autolink <strong>first.last@example.com</strong>