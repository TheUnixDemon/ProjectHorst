1. one
2. two

repeating numbers:

1. one
1. two

large numbers:

123. one

foo 1. the following should not start a list
100.  
200. 