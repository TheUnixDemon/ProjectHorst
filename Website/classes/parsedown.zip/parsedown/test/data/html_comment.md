<!-- single line -->

paragraph

<!-- 
  multiline -->

paragraph

<!-- sss -->abc

* abcd
* bbbb
* cccc