<div>Markup</div>
_No markdown_ without blank line for **strict** compliance with CommonMark.

**Markdown**