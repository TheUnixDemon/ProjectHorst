[reference link][1]

[1]: http://example.com

[one][website] with a semantic name

[website]: http://example.com

[one][404] with no definition

[multiline
one][website] defined on 2 lines

[one][Label] with a mixed case label and an upper case definition

[LABEL]: http://example.com

[one]
[1] with the a label on the next line

[`link`][website]